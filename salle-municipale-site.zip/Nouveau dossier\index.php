<?php
require_once 'includes/config.php';

// Si déjà connecté → dashboard
if (!empty($_SESSION['user'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email && $password) {
        $user = authenticate($email, $password);
        if ($user) {
            $_SESSION['user'] = $user;
            header('Location: dashboard.php');
            exit;
        } else {
            $error = 'Identifiants incorrects';
        }
    } else {
        $error = 'Veuillez remplir tous les champs';
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion — Salle Municipale d'Aubers</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --dark: #0d1117;
            --card: #161b22;
            --border: #21262d;
            --teal: #00c9a7;
            --teal-dim: rgba(0,201,167,0.12);
            --teal-glow: rgba(0,201,167,0.3);
            --text: #e6edf3;
            --muted: #8b949e;
            --error: #f85149;
        }

        body {
            background: var(--dark);
            color: var(--text);
            font-family: 'DM Sans', sans-serif;
            min-height: 100vh;
            display: grid;
            place-items: center;
            overflow: hidden;
        }

        /* Animated background */
        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background:
                radial-gradient(ellipse 60% 50% at 20% 80%, rgba(0,201,167,0.08) 0%, transparent 60%),
                radial-gradient(ellipse 50% 40% at 80% 20%, rgba(0,150,120,0.06) 0%, transparent 60%);
            pointer-events: none;
        }

        .login-wrap {
            width: 100%;
            max-width: 420px;
            padding: 1.5rem;
            animation: fadeUp 0.6s ease both;
        }

        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(24px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        .brand {
            text-align: center;
            margin-bottom: 2.5rem;
        }

        .brand-icon {
            width: 56px;
            height: 56px;
            background: var(--teal-dim);
            border: 1px solid var(--teal-glow);
            border-radius: 16px;
            display: grid;
            place-items: center;
            margin: 0 auto 1rem;
            font-size: 1.5rem;
        }

        .brand h1 {
            font-family: 'Syne', sans-serif;
            font-weight: 800;
            font-size: 1.4rem;
            color: var(--text);
            letter-spacing: -0.02em;
        }

        .brand p {
            color: var(--muted);
            font-size: 0.85rem;
            margin-top: 0.3rem;
        }

        .card {
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 2rem;
        }

        .field {
            margin-bottom: 1.2rem;
        }

        label {
            display: block;
            font-size: 0.8rem;
            font-weight: 500;
            color: var(--muted);
            text-transform: uppercase;
            letter-spacing: 0.06em;
            margin-bottom: 0.5rem;
        }

        input[type="email"],
        input[type="password"] {
            width: 100%;
            background: var(--dark);
            border: 1px solid var(--border);
            border-radius: 10px;
            padding: 0.75rem 1rem;
            color: var(--text);
            font-family: 'DM Sans', sans-serif;
            font-size: 0.95rem;
            outline: none;
            transition: border-color 0.2s, box-shadow 0.2s;
        }

        input:focus {
            border-color: var(--teal);
            box-shadow: 0 0 0 3px var(--teal-dim);
        }

        .error-box {
            background: rgba(248,81,73,0.1);
            border: 1px solid rgba(248,81,73,0.3);
            color: var(--error);
            border-radius: 10px;
            padding: 0.75rem 1rem;
            font-size: 0.88rem;
            margin-bottom: 1.2rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-login {
            width: 100%;
            background: var(--teal);
            color: #0d1117;
            border: none;
            border-radius: 10px;
            padding: 0.85rem;
            font-family: 'Syne', sans-serif;
            font-weight: 700;
            font-size: 0.95rem;
            letter-spacing: 0.02em;
            cursor: pointer;
            transition: opacity 0.2s, transform 0.1s, box-shadow 0.2s;
            margin-top: 0.5rem;
        }

        .btn-login:hover {
            opacity: 0.9;
            box-shadow: 0 0 20px var(--teal-glow);
        }

        .btn-login:active { transform: scale(0.98); }

        .demo-hint {
            margin-top: 1.5rem;
            padding: 0.9rem 1rem;
            background: var(--teal-dim);
            border: 1px solid rgba(0,201,167,0.2);
            border-radius: 10px;
            font-size: 0.8rem;
            color: var(--muted);
            line-height: 1.6;
        }

        .demo-hint strong { color: var(--teal); }

        .footer-note {
            text-align: center;
            color: var(--muted);
            font-size: 0.75rem;
            margin-top: 1.5rem;
        }
    </style>
</head>
<body>
    <div class="login-wrap">
        <div class="brand">
            <div class="brand-icon">🏛️</div>
            <h1>Salle Municipale</h1>
            <p>Mairie d'Aubers — Gestion d'accès</p>
        </div>

        <div class="card">
            <?php if ($error): ?>
                <div class="error-box">⚠️ <?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form method="POST" action="index.php">
                <div class="field">
                    <label for="email">Adresse e-mail</label>
                    <input type="email" id="email" name="email"
                           value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                           placeholder="votre@email.fr" required autofocus>
                </div>
                <div class="field">
                    <label for="password">Mot de passe</label>
                    <input type="password" id="password" name="password"
                           placeholder="••••••••" required>
                </div>
                <button type="submit" class="btn-login">Se connecter →</button>
            </form>

            <div class="demo-hint">
                <strong>Comptes de démonstration :</strong><br>
                Usager : marie.dupont@email.fr / motdepasse1<br>
                Employé : pierre.martin@email.fr / motdepasse2
            </div>
        </div>

        <p class="footer-note">BTS CIEL IR — Lycée Saint-Joseph Hazebrouck — Session 2026</p>
    </div>
</body>
</html>