# Salle Municipale d'Aubers - Gestion d'Accès

Application web PHP simple pour la gestion d'accès à la salle municipale d'Aubers (version autonome sans API).

## Structure du projet

- `index.php` : Page de connexion
- `dashboard.php` : Tableau de bord utilisateur
- `logout.php` : Déconnexion
- `includes/config.php` : Configuration, base de données en session et fonctions utilitaires
- `api/` : Dossier non utilisé (ancien code)

## Installation et exécution

### Rapide (PHP built-in)
```bash
php -S localhost:8000
```
Puis accédez à `http://localhost:8000/`

### Avec XAMPP/WAMP
1. Placez le projet dans `htdocs/salle-municipale`
2. Démarrez Apache
3. Accédez à `http://localhost/salle-municipale/`

## Comptes de démonstration

- **Usager** : marie.dupont@email.fr / motdepasse1
- **Employé** : pierre.martin@email.fr / motdepasse2

## Fonctionnalités

✅ Connexion utilisateur
✅ Affichage des réservations
✅ Contrôle d'accès à la porte
✅ Interface responsive avec thème sombre
✅ Données en session (pas de base de données externe)

## Architecture

- **Pas d'API externe** : Les données sont gérées directement en session PHP
- **Authentification** : Password hashing PHP natif
- **Réservations** : Stockées en mémoire de session
- **Porte** : Contrôle basé sur les réservations validées

## Notes

Version autonome sans dépendances externes. Les données sont réinitialisées à chaque nouveau démarrage du serveur.