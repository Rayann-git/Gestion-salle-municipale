<?php
/**
 * Configuration & helpers - Salle Municipale d'Aubers
 * Version simplifiée sans API
 */

session_start();

// --- Base de données en session ---
if (empty($_SESSION['db_initialized'])) {
    $_SESSION['users'] = [
        ['id' => 1, 'nom' => 'Dupont', 'prenom' => 'Marie', 'email' => 'marie.dupont@email.fr', 'password' => password_hash('motdepasse1', PASSWORD_DEFAULT), 'role' => 'usager'],
        ['id' => 2, 'nom' => 'Martin', 'prenom' => 'Pierre', 'email' => 'pierre.martin@email.fr', 'password' => password_hash('motdepasse2', PASSWORD_DEFAULT), 'role' => 'employe'],
        ['id' => 3, 'nom' => 'Test', 'prenom' => 'User', 'email' => 'Test@test.com', 'password' => password_hash('Test', PASSWORD_DEFAULT), 'role' => 'usager'],
    ];
    
    $_SESSION['reservations'] = [
        ['id' => 1, 'user_id' => 1, 'salle' => 'Espace Culturel des Étangs', 'date' => '2026-04-28', 'date_fin' => '2026-04-29', 'heure_debut' => '14:00', 'heure_fin' => '18:00', 'statut' => 'validée', 'nb_personnes' => 50],
        ['id' => 2, 'user_id' => 1, 'salle' => 'Espace Culturel des Étangs', 'date' => '2026-05-10', 'date_fin' => '2026-05-10', 'heure_debut' => '09:00', 'heure_fin' => '12:00', 'statut' => 'en attente', 'nb_personnes' => 20],
        ['id' => 3, 'user_id' => 2, 'salle' => 'Espace Culturel des Étangs', 'date' => '2026-04-25', 'date_fin' => '2026-04-25', 'heure_debut' => '18:00', 'heure_fin' => '22:00', 'statut' => 'validée', 'nb_personnes' => 80],
    ];
    
    $_SESSION['door_status'] = ['open' => false, 'last_action' => null, 'last_user' => null];
    $_SESSION['db_initialized'] = true;
}

/**
 * Authentifier un utilisateur
 */
function authenticate(string $email, string $password): ?array {
    foreach ($_SESSION['users'] as $user) {
        if ($user['email'] === $email && password_verify($password, $user['password'])) {
            return ['id' => $user['id'], 'nom' => $user['nom'], 'prenom' => $user['prenom'], 'role' => $user['role']];
        }
    }
    return null;
}

/**
 * Récupérer les réservations d'un utilisateur
 */
function get_user_reservations(int $user_id): array {
    return array_values(array_filter($_SESSION['reservations'], fn($r) => $r['user_id'] === $user_id));
}

/**
 * Ouvrir la porte pour un utilisateur
 */
function open_door(int $user_id): array {
    $today = date('Y-m-d');
    $has_reservation = false;
    
    // Vérifier si l'utilisateur a une réservation valide aujourd'hui
    foreach ($_SESSION['reservations'] as $r) {
        if ($r['user_id'] === $user_id && $r['date'] === $today && $r['statut'] === 'validée') {
            $has_reservation = true;
            break;
        }
    }
    
    // Les employés peuvent toujours ouvrir
    foreach ($_SESSION['users'] as $u) {
        if ($u['id'] === $user_id && $u['role'] === 'employe') {
            $has_reservation = true;
            break;
        }
    }
    
    if ($has_reservation) {
        $_SESSION['door_status'] = ['open' => true, 'last_action' => date('H:i:s'), 'last_user' => $user_id];
        return ['success' => true, 'message' => 'Porte ouverte avec succès', 'door_open' => true, 'timestamp' => date('H:i:s')];
    } else {
        return ['success' => false, 'message' => 'Accès refusé : aucune réservation valide aujourd\'hui', 'door_open' => false];
    }
}

/**
 * Vérifie si l'utilisateur est connecté, redirige sinon
 */
function require_login(): void {
    if (empty($_SESSION['user'])) {
        header('Location: index.php');
        exit;
    }
}

/**
 * Retourne l'utilisateur connecté
 */
function current_user(): ?array {
    return $_SESSION['user'] ?? null;
}
?>