<?php
require_once 'includes/config.php';
require_login();

$user = current_user();

// Récupérer les réservations directement
$reservations = get_user_reservations($user['id']);

// Gérer l'ouverture de porte
$door_message = '';
$door_success = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['open_door'])) {
    $result = open_door($user['id']);
    $door_success = $result['success'];
    $door_message = $result['message'];
}

// Statuts couleurs
function statut_class(string $statut): string {
    return match($statut) {
        'validée'    => 'badge-green',
        'en attente' => 'badge-yellow',
        'refusée'    => 'badge-red',
        default      => 'badge-grey'
    };
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord — Salle Municipale d'Aubers</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --dark: #0d1117;
            --card: #161b22;
            --card2: #1c2128;
            --border: #21262d;
            --teal: #00c9a7;
            --teal-dim: rgba(0,201,167,0.12);
            --teal-glow: rgba(0,201,167,0.35);
            --text: #e6edf3;
            --muted: #8b949e;
            --green: #3fb950;
            --yellow: #d29922;
            --red: #f85149;
        }

        body {
            background: var(--dark);
            color: var(--text);
            font-family: 'DM Sans', sans-serif;
            min-height: 100vh;
        }

        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background: radial-gradient(ellipse 70% 50% at 10% 90%, rgba(0,201,167,0.06) 0%, transparent 60%);
            pointer-events: none;
            z-index: 0;
        }

        /* NAV */
        nav {
            position: sticky;
            top: 0;
            z-index: 100;
            background: rgba(13,17,23,0.9);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid var(--border);
            padding: 0 2rem;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .nav-brand {
            font-family: 'Syne', sans-serif;
            font-weight: 800;
            font-size: 1rem;
            display: flex;
            align-items: center;
            gap: 0.6rem;
        }

        .nav-brand span { color: var(--teal); }

        .nav-right {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .nav-user {
            font-size: 0.85rem;
            color: var(--muted);
        }

        .nav-user strong { color: var(--text); }

        .btn-logout {
            background: transparent;
            border: 1px solid var(--border);
            color: var(--muted);
            border-radius: 8px;
            padding: 0.4rem 0.9rem;
            font-size: 0.82rem;
            font-family: 'DM Sans', sans-serif;
            cursor: pointer;
            text-decoration: none;
            transition: border-color 0.2s, color 0.2s;
        }

        .btn-logout:hover { border-color: var(--red); color: var(--red); }

        /* MAIN */
        main {
            max-width: 900px;
            margin: 0 auto;
            padding: 2.5rem 1.5rem;
            position: relative;
            z-index: 1;
        }

        .page-title {
            font-family: 'Syne', sans-serif;
            font-weight: 800;
            font-size: 1.6rem;
            margin-bottom: 0.3rem;
        }

        .page-sub {
            color: var(--muted);
            font-size: 0.9rem;
            margin-bottom: 2rem;
        }

        /* DOOR CARD */
        .door-card {
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1.5rem;
            flex-wrap: wrap;
            animation: fadeUp 0.4s ease both;
        }

        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(16px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        .door-info h2 {
            font-family: 'Syne', sans-serif;
            font-weight: 700;
            font-size: 1.15rem;
            margin-bottom: 0.3rem;
        }

        .door-info p { color: var(--muted); font-size: 0.88rem; }

        .door-status {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.85rem;
            margin-top: 0.6rem;
        }

        .status-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: var(--muted);
        }

        .status-dot.closed { background: var(--red); box-shadow: 0 0 6px var(--red); }
        .status-dot.open   { background: var(--green); box-shadow: 0 0 6px var(--green); animation: pulse 1.5s infinite; }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        /* OPEN DOOR BUTTON */
        .btn-open {
            background: var(--teal);
            color: #0d1117;
            border: none;
            border-radius: 14px;
            padding: 1rem 1.8rem;
            font-family: 'Syne', sans-serif;
            font-weight: 700;
            font-size: 1rem;
            cursor: pointer;
            transition: opacity 0.2s, transform 0.15s, box-shadow 0.2s;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            white-space: nowrap;
        }

        .btn-open:hover {
            opacity: 0.9;
            box-shadow: 0 0 28px var(--teal-glow);
        }

        .btn-open:active { transform: scale(0.96); }

        /* DOOR FEEDBACK */
        .door-feedback {
            margin-top: 1rem;
            padding: 0.8rem 1.1rem;
            border-radius: 10px;
            font-size: 0.88rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            animation: fadeUp 0.3s ease;
        }

        .door-feedback.success {
            background: rgba(63,185,80,0.12);
            border: 1px solid rgba(63,185,80,0.3);
            color: var(--green);
        }

        .door-feedback.error {
            background: rgba(248,81,73,0.1);
            border: 1px solid rgba(248,81,73,0.3);
            color: var(--red);
        }

        /* SECTION TITLE */
        .section-title {
            font-family: 'Syne', sans-serif;
            font-weight: 700;
            font-size: 1.05rem;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .section-title::after {
            content: '';
            flex: 1;
            height: 1px;
            background: var(--border);
        }

        /* RESERVATIONS */
        .reservations-grid {
            display: grid;
            gap: 0.9rem;
            animation: fadeUp 0.5s ease 0.1s both;
        }

        .resa-card {
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 14px;
            padding: 1.2rem 1.4rem;
            display: grid;
            grid-template-columns: 1fr auto;
            align-items: center;
            gap: 1rem;
            transition: border-color 0.2s;
        }

        .resa-card:hover { border-color: rgba(0,201,167,0.25); }

        .resa-date {
            font-family: 'Syne', sans-serif;
            font-weight: 700;
            font-size: 1rem;
            color: var(--teal);
        }

        .resa-salle {
            font-size: 0.92rem;
            margin: 0.15rem 0;
        }

        .resa-meta {
            font-size: 0.82rem;
            color: var(--muted);
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }

        /* BADGES */
        .badge {
            display: inline-block;
            padding: 0.3rem 0.75rem;
            border-radius: 20px;
            font-size: 0.78rem;
            font-weight: 500;
            white-space: nowrap;
        }

        .badge-green  { background: rgba(63,185,80,0.15);  color: var(--green); border: 1px solid rgba(63,185,80,0.3); }
        .badge-yellow { background: rgba(210,153,34,0.15); color: var(--yellow); border: 1px solid rgba(210,153,34,0.3); }
        .badge-red    { background: rgba(248,81,73,0.12);  color: var(--red);  border: 1px solid rgba(248,81,73,0.3); }
        .badge-grey   { background: rgba(139,148,158,0.1); color: var(--muted); border: 1px solid var(--border); }

        .empty-state {
            text-align: center;
            padding: 3rem 1rem;
            color: var(--muted);
            background: var(--card);
            border: 1px dashed var(--border);
            border-radius: 14px;
        }

        .empty-state .icon { font-size: 2.5rem; margin-bottom: 0.8rem; }
        .empty-state p { font-size: 0.9rem; }

        @media (max-width: 600px) {
            .door-card { flex-direction: column; align-items: flex-start; }
            .btn-open { width: 100%; justify-content: center; }
        }
    </style>
</head>
<body>
    <nav>
        <div class="nav-brand">🏛️ <span>Aubers</span> — Accès Salle</div>
        <div class="nav-right">
            <span class="nav-user">
                Bonjour, <strong><?= htmlspecialchars($user['prenom'] . ' ' . $user['nom']) ?></strong>
                <?php if ($user['role'] === 'employe'): ?>
                    <span class="badge badge-teal" style="margin-left:0.4rem;background:var(--teal-dim);color:var(--teal);border:1px solid var(--teal-glow);padding:0.2rem 0.5rem;border-radius:8px;font-size:0.7rem;">Employé</span>
                <?php endif; ?>
            </span>
            <a href="logout.php" class="btn-logout">Déconnexion</a>
        </div>
    </nav>

    <main>
        <h1 class="page-title">Tableau de bord</h1>
        <p class="page-sub">Espace Culturel des Étangs — Mairie d'Aubers</p>

        <!-- DOOR CONTROL -->
        <div class="door-card">
            <div class="door-info">
                <h2>🚪 Contrôle d'accès</h2>
                <p>Ouvrir la porte principale de la salle</p>
                <div class="door-status">
                    <div class="status-dot closed" id="statusDot"></div>
                    <span id="statusText">Porte verrouillée</span>
                </div>
            </div>

            <form method="POST" action="dashboard.php" id="doorForm">
                <input type="hidden" name="open_door" value="1">
                <button type="submit" class="btn-open">
                    🔓 Ouvrir la porte
                </button>
            </form>
        </div>

        <?php if ($door_message): ?>
            <div class="door-feedback <?= $door_success ? 'success' : 'error' ?>">
                <?= $door_success ? '✅' : '🚫' ?>
                <?= htmlspecialchars($door_message) ?>
                <?php if ($door_success): ?>
                    <span style="margin-left:auto;font-size:0.78rem;opacity:0.7;">La porte se verrouille automatiquement après 10 secondes</span>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <!-- RESERVATIONS -->
        <div style="margin-top: 2.5rem;">
            <div class="section-title">📅 Mes réservations</div>

            <?php if (empty($reservations)): ?>
                <div class="empty-state">
                    <div class="icon">📋</div>
                    <p>Aucune réservation trouvée.<br>Rendez-vous sur le site public pour réserver.</p>
                </div>
            <?php else: ?>
                <div class="reservations-grid">
                    <?php foreach ($reservations as $r): ?>
                        <div class="resa-card">
                            <div>
                                <div class="resa-date">
                                    <?php
                                    $start_date = date('d/m/Y', strtotime($r['date']));
                                    $end_date = date('d/m/Y', strtotime($r['date_fin']));
                                    echo $start_date . ($start_date !== $end_date ? ' – ' . $end_date : '');
                                    ?>
                                </div>
                                <div class="resa-salle"><?= htmlspecialchars($r['salle']) ?></div>
                                <div class="resa-meta">
                                    <span>🕐 <?= $r['heure_debut'] ?> – <?= $r['heure_fin'] ?></span>
                                    <span>👥 <?= $r['nb_personnes'] ?> personnes</span>
                                </div>
                            </div>
                            <div>
                                <span class="badge <?= statut_class($r['statut']) ?>">
                                    <?= htmlspecialchars($r['statut']) ?>
                                </span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <script>
        // Mise à jour visuelle statut porte après ouverture
        <?php if ($door_success): ?>
        const dot = document.getElementById('statusDot');
        const txt = document.getElementById('statusText');
        dot.classList.remove('closed');
        dot.classList.add('open');
        txt.textContent = 'Porte ouverte';
        // Retour verrouillé après 10s (simulation)
        setTimeout(() => {
            dot.classList.remove('open');
            dot.classList.add('closed');
            txt.textContent = 'Porte verrouillée';
        }, 10000);
        <?php endif; ?>
    </script>
</body>
</html>