#!/usr/bin/env python3
"""
Demo Simulation - Salle Municipale d'Aubers
Standalone demo without requiring PHP server
Simulates the user flow: login, dashboard, reservations, door access
"""

import json
from datetime import datetime

# Simulated database (same as in api.php)
users_db = [
    {'id': 1, 'nom': 'Dupont', 'prenom': 'Marie', 'email': 'marie.dupont@email.fr', 'password_hash': '$2y$10$examplehash1', 'role': 'usager'},
    {'id': 2, 'nom': 'Martin', 'prenom': 'Pierre', 'email': 'pierre.martin@email.fr', 'password_hash': '$2y$10$examplehash2', 'role': 'employe'},
    {'id': 3, 'nom': 'Test', 'prenom': 'User', 'email': 'Test@test.com', 'password_hash': '$2y$10$examplehash3', 'role': 'usager'},
]

reservations_db = [
    {'id': 1, 'user_id': 1, 'salle': 'Espace Culturel des Étangs', 'date': '2026-04-28', 'date_fin': '2026-04-29', 'heure_debut': '14:00', 'heure_fin': '18:00', 'statut': 'validée', 'nb_personnes': 50},
    {'id': 2, 'user_id': 1, 'salle': 'Espace Culturel des Étangs', 'date': '2026-05-10', 'date_fin': '2026-05-10', 'heure_debut': '09:00', 'heure_fin': '12:00', 'statut': 'en attente', 'nb_personnes': 20},
    {'id': 3, 'user_id': 2, 'salle': 'Espace Culturel des Étangs', 'date': '2026-04-25', 'date_fin': '2026-04-25', 'heure_debut': '18:00', 'heure_fin': '22:00', 'statut': 'validée', 'nb_personnes': 80},
]

def simulate_password_verify(password, hash):
    # Simple simulation - in real PHP, use password_verify
    return (password == 'motdepasse1' and hash == '$2y$10$examplehash1') or (password == 'motdepasse2' and hash == '$2y$10$examplehash2') or (password == 'Test' and hash == '$2y$10$examplehash3')

def api_login(email, password):
    for user in users_db:
        if user['email'] == email and simulate_password_verify(password, user['password_hash']):
            token = f"{user['id']}:{int(datetime.now().timestamp())}:{hash(user['email'])}"
            return {
                'success': True,
                'token': token,
                'user': {
                    'id': user['id'],
                    'nom': user['nom'],
                    'prenom': user['prenom'],
                    'role': user['role']
                }
            }
    return {'success': False, 'message': 'Email ou mot de passe incorrect'}

def api_get_reservations(user_id):
    user_reservations = [r for r in reservations_db if r['user_id'] == user_id]
    return {'success': True, 'reservations': user_reservations}

def api_open_door(user_id):
    today = datetime.now().strftime('%Y-%m-%d')
    has_reservation = any(r['user_id'] == user_id and r['date'] == today and r['statut'] == 'validée' for r in reservations_db)
    is_employee = any(u['id'] == user_id and u['role'] == 'employe' for u in users_db)

    if has_reservation or is_employee:
        return {
            'success': True,
            'message': 'Porte ouverte avec succès',
            'door_open': True,
            'timestamp': datetime.now().strftime('%H:%M:%S')
        }
    else:
        return {
            'success': False,
            'message': 'Accès refusé : aucune réservation valide aujourd\'hui',
            'door_open': False
        }

def demo():
    print("🏛️  DEMO - Salle Municipale d'Aubers")
    print("=" * 50)

    # Simulation de connexion avec comptes demo
    print("\n🔐 Simulation de connexion...")
    demo_accounts = [
        ('marie.dupont@email.fr', 'motdepasse1', 'Usager'),
        ('pierre.martin@email.fr', 'motdepasse2', 'Employé'),
        ('Test@test.com', 'Test', 'Test User')
    ]

    for email, password, role_desc in demo_accounts:
        print(f"\n--- Test avec {role_desc} ---")
        login_result = api_login(email, password)
        if not login_result['success']:
            print(f"❌ {login_result['message']}")
            continue

        user = login_result['user']
        print(f"✅ Connexion réussie! Bienvenue {user['prenom']} {user['nom']} ({user['role']})")

        # Simulation du dashboard - réservations
        print("\n📅 Vos réservations:")
        reservations_result = api_get_reservations(user['id'])
        if reservations_result['reservations']:
            for r in reservations_result['reservations']:
                date_start = datetime.strptime(r['date'], '%Y-%m-%d').strftime('%d/%m/%Y')
                date_end = datetime.strptime(r['date_fin'], '%Y-%m-%d').strftime('%d/%m/%Y')
                date_display = date_start if date_start == date_end else f"{date_start} – {date_end}"
                print(f"  • {date_display} - {r['salle']} ({r['heure_debut']} - {r['heure_fin']}) - {r['nb_personnes']} personnes - {r['statut']}")
        else:
            print("  📋 Aucune réservation trouvée.")

        # Simulation ouverture porte
        print("\n🚪 Simulation ouverture porte...")
        door_result = api_open_door(user['id'])
        if door_result['success']:
            print(f"✅ {door_result['message']}")
            print(f"   Porte ouverte à {door_result['timestamp']}")
            print("   🔒 La porte se verrouille automatiquement après 10 secondes")
        else:
            print(f"❌ {door_result['message']}")

    print("\n" + "=" * 50)
    print("🎯 Demo terminée!")

if __name__ == "__main__":
    demo()