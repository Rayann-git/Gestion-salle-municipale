<?php
/**
 * API simulée - Salle Municipale d'Aubers
 * Candidat 2 - Léonard Decotignie
 * 
 * À remplacer par les vrais endpoints du Candidat 3 (services WEB JSON)
 * Communication en JSON via HTTP
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// --- SIMULATION BDD (à remplacer par vraie BDD MySQL du Candidat 4) ---
$users_db = [
    ['id' => 1, 'nom' => 'Dupont', 'prenom' => 'Marie', 'email' => 'marie.dupont@email.fr', 'password' => password_hash('motdepasse1', PASSWORD_DEFAULT), 'role' => 'usager'],
    ['id' => 2, 'nom' => 'Martin', 'prenom' => 'Pierre', 'email' => 'pierre.martin@email.fr', 'password' => password_hash('motdepasse2', PASSWORD_DEFAULT), 'role' => 'employe'],
];

$reservations_db = [
    ['id' => 1, 'user_id' => 1, 'salle' => 'Espace Culturel des Étangs', 'date' => '2026-04-28', 'heure_debut' => '14:00', 'heure_fin' => '18:00', 'statut' => 'validée', 'nb_personnes' => 50],
    ['id' => 2, 'user_id' => 1, 'salle' => 'Espace Culturel des Étangs', 'date' => '2026-05-10', 'heure_debut' => '09:00', 'heure_fin' => '12:00', 'statut' => 'en attente', 'nb_personnes' => 20],
    ['id' => 3, 'user_id' => 2, 'salle' => 'Espace Culturel des Étangs', 'date' => '2026-04-25', 'heure_debut' => '18:00', 'heure_fin' => '22:00', 'statut' => 'validée', 'nb_personnes' => 80],
];

$door_status = ['open' => false, 'last_action' => null, 'last_user' => null];

$action = $_GET['action'] ?? $_POST['action'] ?? '';

switch ($action) {
    // --- LOGIN ---
    case 'login':
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';
        foreach ($users_db as $user) {
            if ($user['email'] === $email && password_verify($password, $user['password'])) {
                $token = base64_encode($user['id'] . ':' . time() . ':' . md5($user['email']));
                echo json_encode(['success' => true, 'token' => $token, 'user' => ['id' => $user['id'], 'nom' => $user['nom'], 'prenom' => $user['prenom'], 'role' => $user['role']]]);
                exit;
            }
        }
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Email ou mot de passe incorrect']);
        break;

    // --- RESERVATIONS ---
    case 'get_reservations':
        $user_id = intval($_GET['user_id'] ?? 0);
        $user_reservations = array_values(array_filter($reservations_db, fn($r) => $r['user_id'] === $user_id));
        echo json_encode(['success' => true, 'reservations' => $user_reservations]);
        break;

    // --- OUVRIR LA PORTE ---
    case 'open_door':
        $user_id = intval($_POST['user_id'] ?? 0);
        // Vérifier si l'utilisateur a une réservation valide aujourd'hui
        $today = date('Y-m-d');
        $has_reservation = false;
        foreach ($reservations_db as $r) {
            if ($r['user_id'] === $user_id && $r['date'] === $today && $r['statut'] === 'validée') {
                $has_reservation = true;
                break;
            }
        }
        // Employés peuvent toujours ouvrir
        foreach ($users_db as $u) {
            if ($u['id'] === $user_id && $u['role'] === 'employe') {
                $has_reservation = true;
            }
        }
        if ($has_reservation) {
            echo json_encode(['success' => true, 'message' => 'Porte ouverte avec succès', 'door_open' => true, 'timestamp' => date('H:i:s')]);
        } else {
            http_response_code(403);
            echo json_encode(['success' => false, 'message' => 'Accès refusé : aucune réservation valide aujourd\'hui', 'door_open' => false]);
        }
        break;

    // --- STATUT PORTE ---
    case 'door_status':
        echo json_encode(['success' => true, 'door_open' => false, 'timestamp' => date('H:i:s')]);
        break;

    default:
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Action inconnue']);
}
?>